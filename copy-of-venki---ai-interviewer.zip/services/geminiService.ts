
import { GoogleGenAI, Type } from "@google/genai";
import { MODEL_TEXT, EVALUATOR_INSTRUCTION } from "../constants";
import { CandidateProfile, EvaluationScore, InterviewTurn } from "../types";

export const analyzeResume = async (text: string): Promise<CandidateProfile> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const response = await ai.models.generateContent({
    model: MODEL_TEXT,
    contents: `Analyze the following resume text and extract key details:
    ---
    ${text}
    ---`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          name: { type: Type.STRING },
          education: { type: Type.ARRAY, items: { type: Type.STRING } },
          skills: { type: Type.ARRAY, items: { type: Type.STRING } },
          experience: { type: Type.STRING },
          resumeSummary: { type: Type.STRING }
        },
        required: ["name", "education", "skills", "experience", "resumeSummary"]
      }
    }
  });

  return JSON.parse(response.text);
};

export const evaluateInterview = async (
  profile: CandidateProfile,
  transcript: InterviewTurn[]
): Promise<EvaluationScore> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const transcriptText = transcript.map(t => `${t.role.toUpperCase()}: ${t.text}`).join('\n');
  
  const response = await ai.models.generateContent({
    model: MODEL_TEXT,
    contents: `Candidate Profile:
    ${JSON.stringify(profile, null, 2)}
    
    Interview Transcript:
    ${transcriptText}`,
    config: {
      systemInstruction: EVALUATOR_INSTRUCTION,
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          technical: { type: Type.NUMBER },
          communication: { type: Type.NUMBER },
          confidence: { type: Type.NUMBER },
          criticalThinking: { type: Type.NUMBER },
          suitability: { type: Type.NUMBER },
          summary: { type: Type.STRING },
          technicalAnalysis: { type: Type.STRING },
          redFlags: { type: Type.ARRAY, items: { type: Type.STRING } },
          recommendation: { 
            type: Type.STRING,
            description: "Recommendation: STRONG_HIRE, LEAN_HIRE, LEAN_NO_HIRE, STRONG_NO_HIRE"
          }
        },
        required: ["technical", "communication", "confidence", "criticalThinking", "suitability", "summary", "technicalAnalysis", "redFlags", "recommendation"]
      }
    }
  });

  return JSON.parse(response.text);
};
