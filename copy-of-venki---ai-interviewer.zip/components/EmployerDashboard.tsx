
import React from 'react';
import { CandidateProfile, EvaluationScore } from '../types';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';

interface EmployerDashboardProps {
  profile: CandidateProfile;
  score: EvaluationScore;
  jobRole: string;
  onReset: () => void;
}

export const EmployerDashboard: React.FC<EmployerDashboardProps> = ({ profile, score, jobRole, onReset }) => {
  const chartData = [
    { name: 'Technical', score: score.technical, color: '#6366f1' },
    { name: 'Critical Thinking', score: score.criticalThinking, color: '#8b5cf6' },
    { name: 'Communcation', score: score.communication, color: '#10b981' },
    { name: 'Confidence', score: score.confidence, color: '#f59e0b' },
  ];

  const getRecColor = (rec: string) => {
    if (rec.includes('STRONG_HIRE')) return 'bg-emerald-500 text-white';
    if (rec.includes('LEAN_HIRE')) return 'bg-emerald-900/40 text-emerald-400 border border-emerald-500/30';
    if (rec.includes('LEAN_NO_HIRE')) return 'bg-amber-900/40 text-amber-400 border border-amber-500/30';
    return 'bg-red-900/40 text-red-400 border border-red-500/30';
  };

  const getRecLabel = (rec: string) => rec.replace('_', ' ');

  return (
    <div className="w-full animate-fadeIn pb-12">
      <div className="flex flex-col md:flex-row justify-between items-start mb-10 gap-6">
        <div>
          <div className="flex items-center gap-3 mb-2">
            <h2 className="text-4xl font-black text-white">{profile.name}</h2>
            <div className={`px-4 py-1 rounded-full text-[10px] font-black uppercase tracking-widest ${getRecColor(score.recommendation)}`}>
              {getRecLabel(score.recommendation)}
            </div>
          </div>
          <p className="text-indigo-400 font-bold text-xl uppercase tracking-tighter">{jobRole}</p>
          <p className="text-slate-500 text-sm mt-1">High-Stakes Performance Audit</p>
        </div>
        <div className="bg-slate-800/80 p-6 rounded-3xl border border-slate-700 flex flex-col items-center min-w-[140px] shadow-2xl">
          <span className={`text-5xl font-black ${score.suitability > 80 ? 'text-emerald-400' : 'text-slate-400'}`}>
            {score.suitability}%
          </span>
          <span className="text-[10px] uppercase font-black text-slate-500 tracking-[0.2em] mt-2">Overall Fit</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-10">
        <div className="lg:col-span-2 space-y-8">
          {/* Detailed Technical Analysis */}
          <div className="bg-slate-800/40 rounded-3xl p-8 border border-slate-700 shadow-sm relative overflow-hidden">
            <div className="absolute top-0 right-0 p-4 opacity-10">
              <svg className="w-24 h-24" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-6h2v6zm0-8h-2V7h2v2z"/></svg>
            </div>
            <h3 className="text-xs font-black text-slate-400 uppercase tracking-widest mb-4 flex items-center gap-2">
              <span className="w-2 h-2 bg-indigo-500 rounded-full animate-pulse"></span>
              Technical Deep Dive
            </h3>
            <p className="text-slate-200 text-sm leading-relaxed whitespace-pre-line">
              {score.technicalAnalysis}
            </p>
          </div>

          {/* Metrics Chart */}
          <div className="bg-slate-800/20 rounded-3xl p-8 border border-slate-800">
            <h3 className="text-xs font-black mb-8 text-slate-500 uppercase tracking-widest">Skill Competency Matrix</h3>
            <div className="h-64 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={chartData} layout="vertical" margin={{ left: 40 }}>
                  <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#1e293b" />
                  <XAxis type="number" domain={[0, 100]} hide />
                  <YAxis type="category" dataKey="name" width={120} tick={{ fontSize: 10, fill: '#94a3b8', fontWeight: 700 }} />
                  <Bar dataKey="score" radius={[0, 8, 8, 0]} barSize={32}>
                    {chartData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>

        <div className="space-y-6">
          {/* Executive Verdict */}
          <div className="bg-indigo-600 rounded-3xl p-8 shadow-2xl relative">
             <h3 className="text-[10px] font-black text-indigo-200 uppercase tracking-[0.2em] mb-4">Venki's Verdict</h3>
             <p className="text-white text-md leading-relaxed font-bold italic">
                "{score.summary}"
             </p>
          </div>

          {/* Red Flags Section */}
          <div className="bg-red-500/5 border border-red-500/20 rounded-3xl p-6">
            <h3 className="text-[10px] font-black text-red-400 uppercase tracking-widest mb-4 flex items-center gap-2">
              ⚠️ Areas of Concern
            </h3>
            <ul className="space-y-3">
              {score.redFlags.length > 0 ? score.redFlags.map((flag, i) => (
                <li key={i} className="text-slate-400 text-xs flex gap-3 leading-snug">
                  <span className="text-red-500 font-bold">•</span>
                  {flag}
                </li>
              )) : (
                <li className="text-emerald-500 text-xs italic">No significant red flags detected.</li>
              )}
            </ul>
          </div>

          {/* Profile Quick Stats */}
          <div className="bg-slate-800/30 p-6 rounded-3xl border border-slate-800/50">
            <h3 className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-4">Core Skills</h3>
            <div className="flex flex-wrap gap-1.5">
              {profile.skills.map(skill => (
                <span key={skill} className="px-2.5 py-1 bg-slate-900 text-slate-400 rounded-lg text-[9px] font-bold border border-slate-700 uppercase">
                  {skill}
                </span>
              ))}
            </div>
          </div>
        </div>
      </div>

      <div className="border-t border-slate-800 pt-12 flex flex-col items-center gap-6">
         <div className="text-center">
           <p className="text-slate-500 text-[10px] font-black uppercase tracking-[0.3em] mb-2">Audit Timestamp</p>
           <p className="text-slate-400 text-xs font-mono">{new Date().toISOString()}</p>
         </div>
         <button 
          onClick={onReset}
          className="px-12 py-5 bg-white text-slate-950 rounded-2xl font-black uppercase tracking-widest hover:bg-indigo-500 hover:text-white transition-all shadow-2xl active:scale-95 text-sm"
         >
           Process Next Candidate
         </button>
      </div>
    </div>
  );
};
