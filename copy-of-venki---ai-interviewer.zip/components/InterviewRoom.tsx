
import React, { useEffect, useRef, useState, useCallback } from 'react';
import { GoogleGenAI, LiveServerMessage, Modality } from '@google/genai';
import { CandidateProfile, InterviewTurn } from '../types';
import { VENKI_SYSTEM_INSTRUCTION, MODEL_LIVE } from '../constants';
import { createBlob, decode, decodeAudioData } from '../services/audioUtils';

interface InterviewRoomProps {
  profile: CandidateProfile;
  jobRole: string;
  onFinished: (transcript: InterviewTurn[]) => void;
}

export const InterviewRoom: React.FC<InterviewRoomProps> = ({ profile, jobRole, onFinished }) => {
  const [isActive, setIsActive] = useState(false);
  const [transcript, setTranscript] = useState<InterviewTurn[]>([]);
  const [currentVenkiText, setCurrentVenkiText] = useState('');
  const [currentUserText, setCurrentUserText] = useState('');
  const [isVenkiSpeaking, setIsVenkiSpeaking] = useState(false);
  
  const transcriptRef = useRef<InterviewTurn[]>([]);
  const nextStartTimeRef = useRef(0);
  const audioContextsRef = useRef<{ input: AudioContext; output: AudioContext } | null>(null);
  const sessionRef = useRef<any>(null);
  const sourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());

  const handleFinish = useCallback(() => {
    if (sessionRef.current) {
      sessionRef.current.close();
    }
    onFinished(transcriptRef.current);
  }, [onFinished]);

  const addToTranscript = (role: 'user' | 'venki', text: string) => {
    const newTurn: InterviewTurn = { role, text, timestamp: Date.now() };
    transcriptRef.current = [...transcriptRef.current, newTurn];
    setTranscript([...transcriptRef.current]);
  };

  const startSession = async () => {
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      
      const inputCtx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
      const outputCtx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      audioContextsRef.current = { input: inputCtx, output: outputCtx };

      const sessionPromise = ai.live.connect({
        model: MODEL_LIVE,
        callbacks: {
          onopen: () => {
            setIsActive(true);
            const source = inputCtx.createMediaStreamSource(stream);
            const scriptProcessor = inputCtx.createScriptProcessor(4096, 1, 1);
            
            scriptProcessor.onaudioprocess = (e) => {
              const inputData = e.inputBuffer.getChannelData(0);
              const pcmBlob = createBlob(inputData);
              sessionPromise.then(session => {
                session.sendRealtimeInput({ media: pcmBlob });
              });
            };
            
            source.connect(scriptProcessor);
            scriptProcessor.connect(inputCtx.destination);

            sessionPromise.then(session => {
              session.sendRealtimeInput({ 
                text: `The candidate is ${profile.name}. They are applying for the position of ${jobRole}. Here is their profile summary: ${profile.resumeSummary}. Start the interview now by introducing yourself as Venki and asking the first question. Use a professional, cool, and charismatic American tone.`
              });
            });
          },
          onmessage: async (message: LiveServerMessage) => {
            const base64Audio = message.serverContent?.modelTurn?.parts[0]?.inlineData?.data;
            if (base64Audio) {
              setIsVenkiSpeaking(true);
              nextStartTimeRef.current = Math.max(nextStartTimeRef.current, outputCtx.currentTime);
              const audioBuffer = await decodeAudioData(decode(base64Audio), outputCtx, 24000, 1);
              const source = outputCtx.createBufferSource();
              source.buffer = audioBuffer;
              source.connect(outputCtx.destination);
              source.addEventListener('ended', () => {
                sourcesRef.current.delete(source);
                if (sourcesRef.current.size === 0) setIsVenkiSpeaking(false);
              });
              source.start(nextStartTimeRef.current);
              nextStartTimeRef.current += audioBuffer.duration;
              sourcesRef.current.add(source);
            }

            if (message.serverContent?.interrupted) {
              sourcesRef.current.forEach(s => s.stop());
              sourcesRef.current.clear();
              nextStartTimeRef.current = 0;
              setIsVenkiSpeaking(false);
            }

            if (message.serverContent?.outputTranscription) {
              const text = message.serverContent.outputTranscription.text;
              setCurrentVenkiText(prev => prev + text);
            } else if (message.serverContent?.inputTranscription) {
              const text = message.serverContent.inputTranscription.text;
              setCurrentUserText(prev => prev + text);
            }

            if (message.serverContent?.turnComplete) {
              if (currentVenkiText) addToTranscript('venki', currentVenkiText);
              if (currentUserText) addToTranscript('user', currentUserText);
              
              const lowerVenkiText = currentVenkiText.toLowerCase();
              if (lowerVenkiText.includes("interview is complete") || 
                  lowerVenkiText.includes("thank you for your time") ||
                  lowerVenkiText.includes("good luck with your application")) {
                setTimeout(handleFinish, 4000);
              }
              
              setCurrentVenkiText('');
              setCurrentUserText('');
            }
          },
          onerror: (e) => console.error("Live Error", e),
          onclose: () => setIsActive(false),
        },
        config: {
          responseModalities: [Modality.AUDIO],
          systemInstruction: VENKI_SYSTEM_INSTRUCTION + " Use a smooth, charismatic, and cool American male tone. You should sound like a confident and approachable high-level leader.",
          inputAudioTranscription: {},
          outputAudioTranscription: {},
          speechConfig: {
            voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Zephyr' } }
          }
        }
      });

      sessionRef.current = await sessionPromise;
    } catch (err) {
      console.error("Failed to start session", err);
    }
  };

  useEffect(() => {
    startSession();
    return () => {
      if (sessionRef.current) sessionRef.current.close();
      if (audioContextsRef.current) {
        audioContextsRef.current.input.close();
        audioContextsRef.current.output.close();
      }
    };
  }, []);

  return (
    <div className="flex flex-col items-center gap-8 w-full animate-fadeIn">
      <div className="relative">
        <div className={`w-48 h-48 rounded-full bg-slate-800 flex items-center justify-center transition-all duration-500 border-2 border-slate-700 ${isVenkiSpeaking ? 'scale-105 shadow-[0_0_50px_rgba(79,70,229,0.4)] ring-4 ring-indigo-500/50' : 'scale-100 shadow-xl'}`}>
           <div className="relative">
             <span className="text-7xl drop-shadow-2xl">🤵</span>
             {isVenkiSpeaking && (
               <div className="absolute -bottom-2 -right-2 flex gap-1">
                 <span className="w-2 h-2 bg-indigo-400 rounded-full animate-bounce [animation-delay:-0.3s]"></span>
                 <span className="w-2 h-2 bg-indigo-400 rounded-full animate-bounce [animation-delay:-0.15s]"></span>
                 <span className="w-2 h-2 bg-indigo-400 rounded-full animate-bounce"></span>
               </div>
             )}
           </div>
        </div>
        <div className="absolute -bottom-4 left-1/2 -translate-x-1/2 bg-indigo-600 text-white px-5 py-1.5 rounded-full text-xs font-black uppercase tracking-widest shadow-2xl border border-indigo-400/30">
          {isVenkiSpeaking ? 'Venki Speaking' : 'Venki Listening'}
        </div>
      </div>

      <div className="w-full max-w-xl bg-slate-900/80 rounded-3xl p-6 h-80 overflow-y-auto flex flex-col gap-5 border border-slate-800/50 backdrop-blur-md scrollbar-hide">
        {transcript.length === 0 && (
          <div className="flex flex-col items-center justify-center h-full opacity-40">
            <div className="w-8 h-8 border-2 border-indigo-500 border-t-transparent rounded-full animate-spin mb-4"></div>
            <p className="text-slate-400 text-sm font-medium italic">Establishing connection with Venki...</p>
          </div>
        )}
        {transcript.map((turn, i) => (
          <div key={i} className={`flex flex-col ${turn.role === 'venki' ? 'items-start' : 'items-end'}`}>
            <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-1.5 px-3">
              {turn.role === 'venki' ? 'Venki' : 'Candidate'}
            </span>
            <p className={`max-w-[85%] px-5 py-3.5 rounded-2xl text-[13px] leading-relaxed shadow-sm ${turn.role === 'venki' ? 'bg-indigo-600/10 text-indigo-100 border border-indigo-500/20 rounded-tl-none' : 'bg-slate-800 text-slate-200 border border-slate-700/50 rounded-tr-none'}`}>
              {turn.text}
            </p>
          </div>
        ))}
        {currentVenkiText && (
          <div className="flex flex-col items-start opacity-70">
            <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-1.5 px-3">Venki</span>
            <p className="max-w-[85%] px-5 py-3.5 rounded-2xl text-[13px] bg-indigo-600/10 text-indigo-100 border border-indigo-500/20 rounded-tl-none italic animate-pulse">
              {currentVenkiText}
            </p>
          </div>
        )}
        {currentUserText && (
          <div className="flex flex-col items-end opacity-70">
            <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-1.5 px-3 text-right">You</span>
            <p className="max-w-[85%] px-5 py-3.5 rounded-2xl text-[13px] bg-slate-800 text-slate-300 border border-slate-700 rounded-tr-none italic">
              {currentUserText}
            </p>
          </div>
        )}
      </div>

      <div className="flex flex-col items-center gap-4">
         <p className="text-slate-500 text-[11px] font-medium text-center px-8 opacity-60">The session will automatically evaluate once Venki confirms the end of the interview.</p>
         <button 
          onClick={handleFinish}
          className="px-10 py-2.5 bg-red-950/20 text-red-500 rounded-xl font-black uppercase tracking-widest hover:bg-red-900/30 transition-all border border-red-900/30 text-[11px] shadow-lg active:scale-95"
        >
          End Session Early
        </button>
      </div>
    </div>
  );
};
