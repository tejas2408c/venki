
import React, { useEffect, useState } from 'react';
import { MODEL_LIVE, MODEL_TEXT } from '../constants';

interface SettingsPageProps {
  onBack: () => void;
  onResetData: () => void;
}

export const SettingsPage: React.FC<SettingsPageProps> = ({ onBack, onResetData }) => {
  const [isConnected, setIsConnected] = useState<boolean | null>(null);

  useEffect(() => {
    const checkStatus = async () => {
      // @ts-ignore
      const status = await window.aistudio.hasSelectedApiKey();
      setIsConnected(status);
    };
    checkStatus();
  }, []);

  const handleUpdateKey = async () => {
    // @ts-ignore
    await window.aistudio.openSelectKey();
    window.location.reload(); // Refresh to apply new key
  };

  return (
    <div className="w-full animate-fadeIn">
      <div className="flex justify-between items-center mb-10">
        <div>
          <h2 className="text-3xl font-black text-white">Environment</h2>
          <p className="text-slate-500 text-sm font-mono uppercase tracking-tighter">System Configuration v1.0.4</p>
        </div>
        <button 
          onClick={onBack}
          className="text-slate-400 hover:text-white text-xs font-black uppercase tracking-widest transition-colors"
        >
          Close Dashboard
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
        <div className="bg-slate-800/40 border border-slate-700 p-6 rounded-2xl">
          <h3 className="text-slate-400 text-[10px] font-black uppercase tracking-widest mb-4">Connection Status</h3>
          <div className="flex items-center gap-4">
            <div className={`w-3 h-3 rounded-full ${isConnected ? 'bg-emerald-500 shadow-[0_0_10px_rgba(16,185,129,0.5)] animate-pulse' : 'bg-red-500'}`}></div>
            <span className="text-xl font-bold text-white">
              {isConnected === null ? 'Scanning...' : isConnected ? 'API_CONNECTED' : 'API_MISSING'}
            </span>
          </div>
          <p className="text-slate-500 text-xs mt-4 leading-relaxed italic">
            {isConnected 
              ? "Venki is currently authenticated and ready for voice sessions." 
              : "AI features are disabled until a valid API key is selected."}
          </p>
          <button 
            onClick={handleUpdateKey}
            className="mt-6 w-full py-3 bg-indigo-600/20 text-indigo-400 border border-indigo-500/30 rounded-xl text-xs font-black uppercase tracking-widest hover:bg-indigo-600 hover:text-white transition-all"
          >
            Update Configuration
          </button>
        </div>

        <div className="bg-slate-800/40 border border-slate-700 p-6 rounded-2xl">
          <h3 className="text-slate-400 text-[10px] font-black uppercase tracking-widest mb-4">Engine Specs</h3>
          <div className="space-y-4 font-mono text-[11px]">
            <div className="flex justify-between border-b border-slate-700 pb-2">
              <span className="text-slate-500">LLM_CORE</span>
              <span className="text-indigo-400">{MODEL_TEXT}</span>
            </div>
            <div className="flex justify-between border-b border-slate-700 pb-2">
              <span className="text-slate-500">LIVE_AUDIO_DRV</span>
              <span className="text-indigo-400">{MODEL_LIVE}</span>
            </div>
            <div className="flex justify-between border-b border-slate-700 pb-2">
              <span className="text-slate-500">LOCAL_STORAGE</span>
              <span className="text-slate-300">Enabled</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">AUTH_MODE</span>
              <span className="text-emerald-400">GCP_SERVICE_KEY</span>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-red-500/5 border border-red-500/20 p-6 rounded-2xl">
        <h3 className="text-red-400 text-[10px] font-black uppercase tracking-widest mb-2">Danger Zone</h3>
        <p className="text-slate-500 text-xs mb-4">Clearing data will permanently delete all candidate profiles and interview transcripts from this device.</p>
        <button 
          onClick={() => {
            if(confirm("Are you absolutely sure? This will wipe the talent pool.")) {
              onResetData();
              alert("Data purged.");
            }
          }}
          className="px-6 py-2 bg-red-950/20 text-red-500 border border-red-900/30 rounded-lg text-[10px] font-black uppercase tracking-widest hover:bg-red-600 hover:text-white transition-all"
        >
          Purge Local Records
        </button>
      </div>

      <div className="mt-8 text-center">
        <a 
          href="https://ai.google.dev/gemini-api/docs/billing" 
          target="_blank" 
          rel="noopener noreferrer"
          className="text-slate-600 hover:text-indigo-400 text-[10px] font-black uppercase tracking-[0.2em] transition-colors"
        >
          Documentation: ai.google.dev/billing
        </a>
      </div>
    </div>
  );
};
