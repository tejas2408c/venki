
import React from 'react';
import { StoredInterview } from '../types';

interface EmployerListViewProps {
  results: StoredInterview[];
  onBack: () => void;
}

export const EmployerListView: React.FC<EmployerListViewProps> = ({ results, onBack }) => {
  const sortedResults = [...results].sort((a, b) => b.score.suitability - a.score.suitability);

  return (
    <div className="w-full animate-fadeIn">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h2 className="text-3xl font-black text-white">Talent Pool</h2>
          <p className="text-slate-400 text-sm">Reviewing results for {new Date().toLocaleDateString()}</p>
        </div>
        <button 
          onClick={onBack}
          className="text-slate-400 hover:text-white text-sm font-bold uppercase tracking-widest transition-colors"
        >
          Exit Dashboard
        </button>
      </div>

      {sortedResults.length === 0 ? (
        <div className="text-center py-20 bg-slate-800/20 rounded-3xl border border-dashed border-slate-700">
          <p className="text-slate-500 italic">No interviews recorded today yet.</p>
        </div>
      ) : (
        <div className="space-y-4">
          {sortedResults.map((result) => (
            <div key={result.id} className="bg-slate-800/40 border border-slate-700 p-6 rounded-2xl hover:border-indigo-500/50 transition-all group">
              <div className="flex flex-col md:flex-row justify-between gap-4">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-1">
                    <h3 className="text-xl font-bold text-white group-hover:text-indigo-300 transition-colors">{result.profile.name}</h3>
                    <span className="px-2 py-0.5 bg-indigo-900/40 text-indigo-300 text-[10px] font-black uppercase rounded border border-indigo-500/20">
                      {result.jobRole}
                    </span>
                  </div>
                  <p className="text-slate-400 text-sm line-clamp-2 leading-relaxed italic">
                    "{result.score.summary}"
                  </p>
                </div>
                
                <div className="flex items-center md:items-end flex-col justify-center min-w-[120px]">
                  <div className={`text-3xl font-black ${result.score.suitability > 75 ? 'text-emerald-400' : 'text-slate-400'}`}>
                    {result.score.suitability}%
                  </div>
                  <div className="text-[10px] font-black uppercase text-slate-500 tracking-tighter">Suitability</div>
                </div>
              </div>
              
              <div className="mt-4 pt-4 border-t border-slate-700/50 flex flex-wrap gap-2">
                {result.profile.skills.slice(0, 5).map(skill => (
                  <span key={skill} className="text-[10px] bg-slate-900 text-slate-400 px-2 py-1 rounded border border-slate-700">
                    {skill}
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}

      <div className="mt-10 p-6 bg-indigo-600/10 rounded-2xl border border-indigo-500/20">
        <h4 className="text-indigo-300 text-xs font-black uppercase tracking-widest mb-2">Hiring Manager Note</h4>
        <p className="text-slate-300 text-sm leading-relaxed">
          Venki has identified <b>{sortedResults.filter(r => r.score.suitability > 80).length}</b> high-match candidates today. 
          Focus your immediate attention on scores above 80% for the best technical and cultural fit.
        </p>
      </div>
    </div>
  );
};
