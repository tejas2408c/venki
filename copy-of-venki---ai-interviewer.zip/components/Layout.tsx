
import React from 'react';

export const Layout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col items-center p-4 md:p-8">
      <header className="w-full max-w-4xl flex items-center justify-between mb-8">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-indigo-600 rounded-lg flex items-center justify-center text-white font-bold text-xl shadow-[0_0_15px_rgba(79,70,229,0.4)]">
            V
          </div>
          <div>
            <h1 className="text-2xl font-bold text-white leading-none">Venki</h1>
            <p className="text-slate-400 text-sm">AI-Powered Interviews</p>
          </div>
        </div>
      </header>
      <main className="w-full max-w-4xl bg-slate-900 rounded-2xl shadow-2xl border border-slate-800 p-6 md:p-10">
        {children}
      </main>
      <footer className="mt-8 text-slate-600 text-sm">
        &copy; 2024 Venki AI Solutions. Excellence in Assessment.
      </footer>
    </div>
  );
};
