
import React, { useState, useEffect } from 'react';
import { Layout } from './components/Layout';
import { InterviewRoom } from './components/InterviewRoom';
import { EmployerDashboard } from './components/EmployerDashboard';
import { EmployerListView } from './components/EmployerListView';
import { SettingsPage } from './components/SettingsPage';
import { AppStep, CandidateProfile, EvaluationScore, InterviewTurn, StoredInterview } from './types';
import { analyzeResume, evaluateInterview } from './services/geminiService';

const EMPLOYER_PASSCODE = "venki2024";

const App: React.FC = () => {
  const [step, setStep] = useState<AppStep>(AppStep.API_KEY_REQUIRED);
  const [resumeText, setResumeText] = useState('');
  const [linkedInUrl, setLinkedInUrl] = useState('');
  const [jobRole, setJobRole] = useState('');
  const [passcode, setPasscode] = useState('');
  const [loginError, setLoginError] = useState(false);
  const [profile, setProfile] = useState<CandidateProfile | null>(null);
  const [score, setScore] = useState<EvaluationScore | null>(null);
  const [storedResults, setStoredResults] = useState<StoredInterview[]>([]);

  useEffect(() => {
    const checkApiKey = async () => {
      // @ts-ignore
      const hasKey = await window.aistudio.hasSelectedApiKey();
      if (hasKey) {
        setStep(AppStep.ROLE_SELECTION);
      }
    };
    checkApiKey();

    const saved = localStorage.getItem('venki_results');
    if (saved) {
      setStoredResults(JSON.parse(saved));
    }
  }, []);

  const handleKeySelection = async () => {
    try {
      // @ts-ignore
      await window.aistudio.openSelectKey();
      setStep(AppStep.ROLE_SELECTION);
    } catch (err) {
      console.error("Key selection failed", err);
    }
  };

  const clearAllData = () => {
    localStorage.removeItem('venki_results');
    setStoredResults([]);
  };

  const saveResult = (newResult: StoredInterview) => {
    const updated = [...storedResults, newResult];
    setStoredResults(updated);
    localStorage.setItem('venki_results', JSON.stringify(updated));
  };

  const isFormValid = (jobRole.trim() !== '') && (resumeText.trim() !== '' || linkedInUrl.trim() !== '');

  const handleStartAnalysis = async () => {
    if (!isFormValid) return;
    setStep(AppStep.ANALYZING);
    try {
      const parsedProfile = await analyzeResume(resumeText || `LinkedIn Profile URL: ${linkedInUrl}`);
      setProfile(parsedProfile);
      setStep(AppStep.INTERVIEWING);
    } catch (err: any) {
      console.error(err);
      if (err.message?.includes("Requested entity was not found")) {
        setStep(AppStep.API_KEY_REQUIRED);
      } else {
        setStep(AppStep.SETUP);
      }
    }
  };

  const handleInterviewFinished = async (transcript: InterviewTurn[]) => {
    setStep(AppStep.EVALUATING);
    try {
      if (profile) {
        const finalScore = await evaluateInterview(profile, transcript);
        const result: StoredInterview = {
          id: Date.now().toString(),
          profile,
          score: finalScore,
          jobRole,
          date: Date.now()
        };
        saveResult(result);
        setScore(finalScore);
        setStep(AppStep.SUMMARY);
      }
    } catch (err: any) {
      console.error(err);
      if (err.message?.includes("Requested entity was not found")) {
        setStep(AppStep.API_KEY_REQUIRED);
      } else {
        setStep(AppStep.SETUP);
      }
    }
  };

  const handleEmployerLogin = () => {
    if (passcode === EMPLOYER_PASSCODE) {
      setStep(AppStep.EMPLOYER_LIST);
      setLoginError(false);
    } else {
      setLoginError(true);
    }
  };

  const renderStep = () => {
    switch (step) {
      case AppStep.API_KEY_REQUIRED:
        return (
          <div className="flex flex-col items-center py-20 space-y-10 animate-fadeIn text-center">
            <div className="relative">
              <div className="w-24 h-24 bg-indigo-600 rounded-3xl flex items-center justify-center text-white font-black text-5xl shadow-[0_0_50px_rgba(79,70,229,0.5)] animate-pulse mb-8">
                V
              </div>
            </div>
            <div className="max-w-md">
              <h2 className="text-4xl font-black text-white mb-4">Initialize Venki</h2>
              <p className="text-slate-400 mb-8 leading-relaxed">
                To enable high-performance AI interviewing, please select a valid API key from your paid Google Cloud project.
              </p>
              <button 
                onClick={handleKeySelection}
                className="w-full bg-white text-slate-950 py-5 rounded-2xl font-black uppercase tracking-widest hover:bg-indigo-500 hover:text-white transition-all shadow-2xl transform hover:-translate-y-1 active:scale-95"
              >
                Select API Key
              </button>
              <a 
                href="https://ai.google.dev/gemini-api/docs/billing" 
                target="_blank" 
                rel="noopener noreferrer"
                className="inline-block mt-6 text-indigo-400 hover:text-indigo-300 text-xs font-bold underline underline-offset-4 decoration-indigo-500/30"
              >
                View Billing Documentation
              </a>
            </div>
          </div>
        );

      case AppStep.SETTINGS:
        return <SettingsPage onBack={() => setStep(AppStep.ROLE_SELECTION)} onResetData={clearAllData} />;

      case AppStep.ROLE_SELECTION:
        return (
          <div className="flex flex-col items-center py-10 space-y-10 animate-fadeIn">
            <div className="text-center">
              <h2 className="text-4xl font-black text-white mb-4">Welcome to Venki</h2>
              <p className="text-slate-400">Professional AI-Driven Recruitment</p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 w-full max-w-lg">
              <button 
                onClick={() => setStep(AppStep.SETUP)}
                className="group relative bg-slate-800 border border-slate-700 p-8 rounded-3xl hover:border-indigo-500 transition-all text-left"
              >
                <div className="text-3xl mb-4">🚀</div>
                <h3 className="text-xl font-bold text-white mb-2 group-hover:text-indigo-400">Candidate</h3>
                <p className="text-slate-500 text-sm">Start your voice interview and show your skills.</p>
              </button>
              <button 
                onClick={() => setStep(AppStep.EMPLOYER_LOGIN)}
                className="group relative bg-slate-800 border border-slate-700 p-8 rounded-3xl hover:border-indigo-500 transition-all text-left"
              >
                <div className="text-3xl mb-4">💼</div>
                <h3 className="text-xl font-bold text-white mb-2 group-hover:text-indigo-400">Employer</h3>
                <p className="text-slate-500 text-sm">Access the dashboard and review candidate results.</p>
              </button>
            </div>
            <button 
              onClick={() => setStep(AppStep.SETTINGS)}
              className="flex items-center gap-2 text-slate-600 hover:text-indigo-400 text-[10px] font-black uppercase tracking-[0.2em] transition-colors"
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37a1.724 1.724 0 002.572-1.065z" />
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
              </svg>
              Environment Settings
            </button>
          </div>
        );

      case AppStep.EMPLOYER_LOGIN:
        return (
          <div className="max-w-md mx-auto py-10 space-y-8 animate-fadeIn">
            <div className="text-center">
              <h2 className="text-3xl font-black text-white mb-2">Employer Access</h2>
              <p className="text-slate-400">Enter your secure passcode to continue.</p>
            </div>
            <div className="space-y-4">
              <input 
                type="password" 
                className={`w-full px-4 py-4 rounded-2xl bg-slate-800 border ${loginError ? 'border-red-500' : 'border-slate-700'} text-white text-center text-2xl tracking-[0.5em] focus:ring-2 focus:ring-indigo-500 outline-none`}
                placeholder="••••••••"
                value={passcode}
                onChange={(e) => {
                  setPasscode(e.target.value);
                  setLoginError(false);
                }}
                onKeyDown={(e) => e.key === 'Enter' && handleEmployerLogin()}
              />
              {loginError && <p className="text-red-400 text-xs font-bold text-center uppercase tracking-widest">Invalid Passcode</p>}
            </div>
            <div className="flex flex-col gap-3">
              <button 
                onClick={handleEmployerLogin}
                className="w-full bg-indigo-600 text-white py-4 rounded-2xl font-black uppercase tracking-widest hover:bg-indigo-500 transition-all"
              >
                Verify & Login
              </button>
              <button 
                onClick={() => setStep(AppStep.ROLE_SELECTION)}
                className="w-full text-slate-500 py-2 text-xs font-bold uppercase tracking-widest hover:text-slate-300"
              >
                Go Back
              </button>
            </div>
          </div>
        );

      case AppStep.EMPLOYER_LIST:
        return <EmployerListView results={storedResults} onBack={() => setStep(AppStep.ROLE_SELECTION)} />;

      case AppStep.SETUP:
        return (
          <div className="space-y-8 animate-fadeIn">
            <div className="flex justify-between items-start">
              <div>
                <h2 className="text-3xl font-black text-white text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 to-cyan-400">Application Info</h2>
                <p className="text-slate-400">Provide your profile to begin the session.</p>
              </div>
              <button onClick={() => setStep(AppStep.ROLE_SELECTION)} className="text-slate-600 hover:text-slate-400 text-xs font-bold uppercase tracking-tighter">Cancel</button>
            </div>

            <div className="space-y-6">
              <label className="block">
                <span className="text-slate-400 font-bold mb-2 block text-[10px] uppercase tracking-widest">Job Role You're Applying For *</span>
                <input 
                  type="text" 
                  className="w-full px-4 py-3 rounded-xl bg-slate-800 border border-slate-700 text-white focus:ring-2 focus:ring-indigo-500 outline-none transition-all placeholder-slate-600"
                  placeholder="e.g. Lead Software Architect"
                  value={jobRole}
                  onChange={(e) => setJobRole(e.target.value)}
                />
              </label>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <label className="block">
                  <span className="text-slate-400 font-bold mb-2 block text-[10px] uppercase tracking-widest">LinkedIn Profile URL</span>
                  <input 
                    type="url" 
                    className="w-full px-4 py-3 rounded-xl bg-slate-800 border border-slate-700 text-white focus:ring-2 focus:ring-indigo-500 outline-none transition-all placeholder-slate-600"
                    placeholder="linkedin.com/in/username"
                    value={linkedInUrl}
                    onChange={(e) => setLinkedInUrl(e.target.value)}
                  />
                </label>

                <div className="flex flex-col justify-end">
                   <p className="text-slate-600 text-[10px] font-black uppercase mb-4 text-center">— OR —</p>
                   <label className="block">
                    <span className="text-slate-400 font-bold mb-2 block text-[10px] uppercase tracking-widest">Resume Content</span>
                    <textarea 
                      className="w-full h-32 px-4 py-3 rounded-xl bg-slate-800 border border-slate-700 text-white focus:ring-2 focus:ring-indigo-500 outline-none transition-all resize-none placeholder-slate-600 text-sm"
                      placeholder="Paste resume text..."
                      value={resumeText}
                      onChange={(e) => setResumeText(e.target.value)}
                    />
                  </label>
                </div>
              </div>
            </div>

            <button 
              onClick={handleStartAnalysis}
              disabled={!isFormValid}
              className="w-full bg-indigo-600 text-white py-4 rounded-2xl font-black uppercase tracking-widest text-lg hover:bg-indigo-500 transition-all shadow-xl disabled:bg-slate-800 disabled:text-slate-600 disabled:cursor-not-allowed transform hover:-translate-y-0.5 active:scale-95 mt-4"
            >
              Enter Interview Room
            </button>
          </div>
        );

      case AppStep.ANALYZING:
        return (
          <div className="flex flex-col items-center py-20 space-y-6">
            <div className="w-20 h-20 border-4 border-slate-800 border-t-indigo-500 rounded-full animate-spin"></div>
            <div className="text-center">
              <h3 className="text-2xl font-black text-white">Venki is analyzing...</h3>
              <p className="text-slate-400 text-sm italic">Synthesizing the perfect assessment for {jobRole}</p>
            </div>
          </div>
        );

      case AppStep.INTERVIEWING:
        return profile ? (
          <InterviewRoom profile={profile} jobRole={jobRole} onFinished={handleInterviewFinished} />
        ) : null;

      case AppStep.EVALUATING:
        return (
          <div className="flex flex-col items-center py-20 space-y-6">
            <div className="w-20 h-20 border-4 border-slate-800 border-t-emerald-500 rounded-full animate-spin"></div>
            <div className="text-center">
              <h3 className="text-2xl font-black text-white">Finalizing Report</h3>
              <p className="text-slate-400 text-sm italic">Quantifying your expertise and confidence...</p>
            </div>
          </div>
        );

      case AppStep.SUMMARY:
        return profile && score ? (
          <EmployerDashboard 
            profile={profile} 
            score={score} 
            jobRole={jobRole}
            onReset={() => {
              setStep(AppStep.ROLE_SELECTION);
              setJobRole('');
              setResumeText('');
              setLinkedInUrl('');
              setPasscode('');
            }} 
          />
        ) : null;

      default:
        return null;
    }
  };

  return (
    <Layout>
      {renderStep()}
    </Layout>
  );
};

export default App;
