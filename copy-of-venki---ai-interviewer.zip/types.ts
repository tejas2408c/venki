
export interface CandidateProfile {
  name: string;
  education: string[];
  skills: string[];
  experience: string;
  resumeSummary: string;
  linkedInUrl?: string;
}

export interface InterviewTurn {
  role: 'user' | 'venki';
  text: string;
  timestamp: number;
}

export interface EvaluationScore {
  technical: number;
  communication: number;
  confidence: number;
  suitability: number;
  summary: string;
  technicalAnalysis: string;
  criticalThinking: number;
  redFlags: string[];
  recommendation: 'STRONG_HIRE' | 'LEAN_HIRE' | 'LEAN_NO_HIRE' | 'STRONG_NO_HIRE';
}

export interface StoredInterview {
  id: string;
  profile: CandidateProfile;
  score: EvaluationScore;
  jobRole: string;
  date: number;
}

export enum AppStep {
  API_KEY_REQUIRED = 'api-key-required',
  ROLE_SELECTION = 'role-selection',
  EMPLOYER_LOGIN = 'employer-login',
  EMPLOYER_LIST = 'employer-list',
  SETTINGS = 'settings',
  SETUP = 'setup',
  ANALYZING = 'analyzing',
  INTERVIEWING = 'interviewing',
  EVALUATING = 'evaluating',
  SUMMARY = 'summary'
}
